package com.annathe.training.networth.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.annathe.training.networth.model.Networth;

@RestController
public class NetworthController {
	
	
	@GetMapping("micro/{stockName}/quantity/{quantity}")
	public Networth calculateNetworth(@PathVariable String stockName, @PathVariable int quantity) {
		
		Networth networth = new Networth();
		
		networth.setStockName(stockName);
		
		networth.setQuantity(quantity);
		
		return networth;
		
		
	}
	

}
