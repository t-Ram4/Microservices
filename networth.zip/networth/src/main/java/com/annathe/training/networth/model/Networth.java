package com.annathe.training.networth.model;

public class Networth {
	
	private String stockName;
	
	private int quantity;
	
	private float networth;

	public String getStockName() {
		return stockName;
	}

	public void setStockName(String stockName) {
		this.stockName = stockName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public float getNetworth() {
		return networth;
	}

	public void setNetworth(float networth) {
		this.networth = networth;
	}
	
	

}
