package com.annathe.training.shareprice.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.annathe.training.shareprice.model.ShareDetails;

@RestController
public class SharePriceController {
	
	
	private Map<String,Float> sharePrices = new HashMap<String,Float>();
	
	public SharePriceController() {
		sharePrices.put("Infy", 2000f);
		
		sharePrices.put("Reliance", 1600f);
		
		sharePrices.put("TCS", 2030f);
		
		sharePrices.put("Maruti", 1000f);
		
	}
	
	@GetMapping("shares/{stockName}")
	public ShareDetails getSharePrice(@PathVariable String stockName) {
		
		ShareDetails shareDetails  = new ShareDetails();
		
		shareDetails.setStockName(stockName);
		
		shareDetails.setPrice(sharePrices.get(stockName)); 
		
		return shareDetails;
		
		
	}
	

}
